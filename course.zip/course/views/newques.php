
<?php
 $id_bd=0;
  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
       $conn2= mysqli_connect($servername,$username,$password,$database);
	   mysqli_set_charset($conn2, 'utf8'); 
?>
<form action="index.php?action=newques" method="POST">
    <div class="container">
	
	     <div  class="inlinetxt"><h1 align="center"> Заповніть форму опитування</h1> </div>

	
<section>

    <div class="inlinetxt" ><b>Введіть потрібне питання</b></div>
    <textarea style="white-space: normal; height: 100px;"  type="text" placeholder="Питання" name="ques" required></textarea><br>
    <div class="inlinetxt"><b>Введіть варіанти відповідей</b></div>
    <input   type="text" placeholder="Введіть 1 відповідь" name="vid1" required>
	<input type="text" placeholder="Введіть 2 відповідь" name="vid2" required>
	<input type="text" placeholder="Введіть 3 відповідь" name="vid3" >
  <span class="error"> </span><br>
    
    <div align = "center"><button type="submit" class="btn2">Додати</button>
  
  <p></p>
  
  <?php 

      if(!empty($_POST)) {
        if (!$conn2) {
      die("Помилка з'єднання: " . mysqli_connect_error());
                    }

     else{			   
         $ques1=$_POST["ques"];
         $vid=$_POST["vid1"];
		 $vidd=$_POST["vid2"];
         $viddd=$_POST["vid3"];
		 $vi1=$_POST["vid3"];
         $query = "SELECT * FROM questions";
         $result = $conn2->query($query);
         $row =$result->fetch_assoc();
               $sql = "INSERT INTO questions (question, variant1,variant2,variant3 ), result (id_question) VALUES ('$ques1', '$vid','$vidd','$viddd'),($vi1)";
                mysqli_query($conn2, $sql);
				header("Location:http://localhost/course/index.php?action=new_question");

	  
	 }

      
	 
	  mysqli_close($conn2);
	  }
  ?>   
</span> </section> 
  


</div>
</form>