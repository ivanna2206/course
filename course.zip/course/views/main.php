 <a name="home"></a>
<div class="containerimage">
  <div class="box">
<a  href='index.php?action=newques'><img src="/course/img/new.jpeg"></a>

  </div>
  <div class="box">
    <a  href='index.php?action=show_question'><img src="/course/img/new1.jpeg"></a></div>
</div>
<?php 
  
  /*if(isset($_SESSION['login']) and !empty($_SESSION['login'])) {

   $s=''; $s=$_SESSION['login'];
   $q=''; $q=$_SESSION['id'];
   $e=''; $e=$_SESSION['neworder'];
   echo "You entered as \n"; echo ($s); echo("<br>"); echo ($q);
   echo "Your order: \n"; echo ($e);echo("\n");
}*/

   ?>