
<form  action="index.php?action=login" method="POST">
  <section>
    <div id="regtext"> <a name="registration">Вхід</a></div>
    <p><a name="login"></a></p>
    <hr>

    <div class="inlinetxt"><label class="log" for="login"><b>Логін</b></label></div>
    <input type="text" placeholder="Введіть електронну пошту" name="login" required>
<br>

    <div class="inlinetxt"><label class="log" for="psw"><b>Пароль</b></label></div>
    <input type="password" placeholder="Введіть пароль" name="psw" required>
<br>
<br>
 <div align="center"><button type="submit" class="registerbtn" >Увійти</button></div>
<span class="error">

 
 <?php 
$auth = False;
if(!empty($_POST)) {
  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
        $conn = mysqli_connect($servername,$username,$password,$database);
        if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
                    }

     else{
       $login1=$_POST["login"];
       $password1=$_POST["psw"];
       //$hash = password_hash($password1, PASSWORD_DEFAULT);
    
    $query = "SELECT * FROM user";
    $result = $conn->query($query);
    while($row = $result->fetch_assoc()){

    if($login1 == $row["login"] && password_verify($password1,$row["password"])) {
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
     $auth = True;
      $_SESSION['login'] = $login1;
      $_SESSION['id'] = $row["id"];

     header("Location:http://localhost/course/index.php?action=home");
    }}
    if($auth == False){
      $Err = "Неправильний логін або пароль!";
      echo $Err;
      }
       
    mysqli_close($conn);
   }
    }         
 ?>
    
</span>
 </section></form>