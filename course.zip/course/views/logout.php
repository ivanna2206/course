<?php 

  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
        $conn3 = mysqli_connect($servername,$username,$password,$database);
        mysqli_set_charset($conn3, 'utf8');
        if (!$conn3) {
      die("Connection failed: " . mysqli_connect_error());
                    }

    else{
        mysqli_close($conn3);
    }

// unset($_SESSION["login"]);
 session_destroy();
 header("Location:http://localhost/course/index.php?action=home");
 ?>