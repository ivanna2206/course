
<?php
 $id_bd=0;
  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
  


?>
<form action="index.php?action=show_question" method="POST">

		     <div  class="inlinetxt"><h1 align="center">Результати опитування </h1> </div><p></p>
  
	 
      <div class="container">	   
<?php 	  
     $conn4 = mysqli_connect($servername,$username,$password,$database);
	   mysqli_set_charset($conn4, 'utf8'); 
 //   if(!empty($_POST)) {
   if ($conn4) {

   $r1 = '<div class = "row">';
   echo $r1;

   $sql1="SELECT * FROM  `questions`  INNER JOIN `result`  ON questions.id=result.id_question";

  $query1=mysqli_query($conn4,$sql1) or die( mysqli_error($conn4));
  while ($row1=mysqli_fetch_array($query1)) {

	    $im1 = '<div  align="center" class = "col-lg-3 col-md-3 col-sm-6"><div class = "link">'.'<p> '.$row1["question"].'</p></div><p>'.$row1["variant1"].' ( <b>'.$row1["count_var1"].' </b>учасників)</p>'.'<p>'.$row1["variant2"].' ( <b>'.$row1["count_var2"].'  </b>учасників)</p>'.'<p>'.$row1["variant3"].'  ( <b>'.$row1["count_var3"].'  </b>учасників)</p>'.'</div>';
 
	echo $im1; 


  }
	echo '</div>';
       

}

	  mysqli_close($conn4);
  ?>   

  

    </div >

</form>
