
<?php
 $id_bd=0;
  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
  
$flag = true;
$fullnamepattern  = '/^([A-Za-z][A-Za-z\-\'])|([А-ЯЁIЇҐЄа-яёіїґє][А-ЯЁIЇҐЄа-яёіїґє\-\'])$/';
$emailpattern = '/^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/';
$fullnameErr =  $emailErr= "";   
$fullname1=  $email1 ='';


?>
<form action="index.php?action=new_question" method="POST">
    <div class="container">
		     <div  class="inlinetxt"><h1 align="center"> Оберіть учасників опитування </h1> </div><p></p>
             <label class="switch"><input type="checkbox" onclick="selectAll(this)"> </input><span class="slider"></span></label><b style="margin-left: 25px;">Відмітити все</b>
		   
<?php 	  
     $conn = mysqli_connect($servername,$username,$password,$database);
	   mysqli_set_charset($conn, 'utf8'); 
 //   if(!empty($_POST)) {
   if ($conn) {
	 $query3 = "SELECT * FROM members";
   $result3 = $conn->query($query3);
   $r1 = '<div class = "row">';
   echo $r1;
  
  while ($row1 =$result3->fetch_assoc()) {
         $im2 = '<div class = "col-lg-3 col-md-3 col-sm-6"><div class = "test">'.'<p>'.$row1["name"].'</p></div><p>'.$row1["email"].'</p>'.'<label class="switch"><input type="checkbox"  name="ml[]" value="'.$row1["id"].'"><span class="slider"></span></label></div>';

	 echo $im2;

  }
	echo '</div>';
       

}
	

		  
echo '<div id="follow">
      <input name="knopka1" type="submit" class="button1" value= "Надіслати лист запрошення"/>
      </div>';
	  
if (isset($_POST['knopka1'])){
	$menuls=array();
if(!empty($_POST['ml'])) {
  foreach($_POST['ml'] as $check) {
      array_push($menuls, $check);
    }

foreach($menuls as $id) {
   if ($conn) {
	$query3 = "SELECT * FROM members WHERE id = '$id'";
   $result3 = $conn->query($query3);

  
  while ($row1 =$result3->fetch_assoc()) {
$to  = $row1["email"]; 
 echo $to;
$subject = "Опитування!"; 
 echo $subject;
$message = ' <p>' .$row1["name"]. ', перейдіть за посиланням та проголосуйте! </p>';
 echo $message;
$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 
$headers .= "From: <palamariuk2206@gmail.com>\r\n"; 



mail($to, $subject, $message, $headers);
//	mail($to, $subject, $message); 
	

  }

       

}	
	
//header("Location:http://localhost/course/index.php?action=show_question");
}}}
	

	echo '<div id="follow">
      <input name="knopka" type="submit" class="knopka" value= "Видалити відмічені"/>
      </div>';
if (isset($_POST['knopka'])){
  $menuls=array();
if(!empty($_POST['ml'])) {
	


  
  foreach($_POST['ml'] as $check) {
      array_push($menuls, $check);
    }

foreach($menuls as $id) {
$inormenu = "DELETE FROM members WHERE id = '$id'";
mysqli_query($conn, $inormenu) ; 
header("Location:http://localhost/course/index.php?action=new_question");
}
       }

}  
 
?>
	
<section>
 
    <div class="inlinetxt"><label class="log" for="fullname"><b>П.І.Б.</b></label></div>
    <input type="text" placeholder="Введіть П.І.Б" name="fullname" >
  <span class="error"> <?php if(!empty($_POST)) {
      if(isset($_POST["fullname"]) && !preg_match ($fullnamepattern, $_POST["fullname"])) {
      $fullnameErr = "Введено некоректно , або нічого не введено!";
	 echo $fullnameErr; $flag = false;
      }
      }
    ?></span><br>
    <div class="inlinetxt"><label class="log" for="email"><b>Ел. пошта</b></label></div>
    <input type="text" placeholder="Введіть електронну адресу" name="email" >
  <span class="error"> <?php if(!empty($_POST)) {
      if(isset($_POST["email"]) && !preg_match ($emailpattern, $_POST["email"])) {
       $emailErr = "Введено некоректно , або нічого не введено!";
	   echo $emailErr; 
       $flag = false;
      }}?></span><br>
    
   
    
    <div align = "center"><button type="submit" class="btn1">Додати</button>
  
  <p></p>
  
  <?php 

      if(!empty($_POST)) {
      if($flag == true) {
        if (!$conn) {
      die("Помилка з'єднання: " . mysqli_connect_error());
                    }

     else{
         $fullname1=$_POST["fullname"];
        $email1=$_POST["email"];
          $query = "SELECT * FROM members";
          $result = $conn->query($query);
          $row =$result->fetch_assoc();
		  if ($row["email"]==$_POST["email"] ){ echo "Даний учасник уже є в базі ! " ; }
	        else { 
                $sql = "INSERT INTO members (name, email) VALUES ('$fullname1', '$email1')";

                mysqli_query($conn, $sql);
				header("Location:http://localhost/course/index.php?action=new_question");
	  }
	

	  mysqli_close($conn);
	  }}}
  ?>   
  </span> </section> 
  


</div>
</form>
