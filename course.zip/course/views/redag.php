
<?php
 $id_bd=0;
  $servername = "localhost";
  $database = "course";
  $username = "root";
  $password = "";
  


?>
<form action="index.php?action=redag" method="POST" method="GET">

		     <div  class="inlinetxt"><h1 align="center">Результати опитування </h1> </div><p></p>
  
    <div class="inlinetxt" ><b>Введіть потрібне питання</b></div>
    <textarea style="white-space: normal; height: 100px;"  type="text" placeholder="Питання" name="quest" required></textarea><br>
    <div class="inlinetxt"><b>Введіть варіанти відповідей</b></div>
    <input   type="text" placeholder="Введіть 1 відповідь" name="vari1" required>
	<input type="text" placeholder="Введіть 2 відповідь" name="vari2" required>
	<input type="text" placeholder="Введіть 3 відповідь" name="vari3" >
  <span class="error"> </span><br>
    
    <div align = "center"><button type="submit" class="btn2">Додати</button>
	 
         
<?php 	  
     $conn5 = mysqli_connect($servername,$username,$password,$database);
	   mysqli_set_charset($conn5, 'utf8'); 
      if(!empty($_POST)) {
        if (!$conn5) {
      die("Помилка з'єднання: " . mysqli_connect_error());
                    }

     else{	


         $sql1="SELECT question, variant1, variant2,variant3  FROM  questions ";
         $query2=mysqli_query($conn5,$sql1) or die( mysqli_error($conn5));	
 		 
         $ques1=$_POST["question"];
         $vid=$_POST["variant1"];
		 $vidd=$_POST["variant2"];
         $viddd=$_POST["variant3"];
 while($row=mysqli_fetch_array($query2)){
        $sql5 = "UPDATE questions SET guestion= `ques1` AND variant1=`$vid` AND variant2=`$vidd` AND variant3=`$viddd`";
        mysqli_query($conn5, $sql);
		header("Location:http://localhost/course/index.php?action=redag");

	  
	 }


	  mysqli_close($conn5);
	  }

	  
	  }
  ?>   

  
</form>
