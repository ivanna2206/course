<section>
    <div id="succtext"><a ><p>Дякуємо за замовлення!</p></a></div><br>
    <div id="succtext"><a ><p>Наш менеджер зателефонує Вам протягом кількох хвилин.</p></a></div><br>
    <div align = "center" id="regtext">
   <p> <a href="index.php?action=home" class = "reglink">Перейти до головної сторінки</a></p></div>
</section>