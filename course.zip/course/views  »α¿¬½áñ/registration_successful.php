<section>
    <div id="regtext"><a name="registration_successful">Ви успішно зареєструвалися!</a></div>
    <a href="index.php?action=home" class = "reglink">Перейти до головної сторінки</a>
</section>