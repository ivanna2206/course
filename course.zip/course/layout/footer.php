<footer class="page-footer">

</footer>
<script src="jquery-3.5.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="main.js"></script>
</body>

</html>
<script>
function selectAll(btn) {
  btn.checkValue = (btn.checkValue != "on")? "on" : "off";
  var value = btn.checkValue == "on";
  
  var boxes = document.querySelectorAll("input[type='checkbox']");
  for (var i = 0; i < boxes.length; i++) {
    boxes[i].checked = value;
  }
}

var linc2 = $('.linc2'),
    timeoutId;
$('.link').hover(function(){
    clearTimeout(timeoutId);
    linc2.show();
}, function(){
    timeoutId = setTimeout($.proxy(linc2,'hide'), 1000)
});
linc2.mouseenter(function(){
    clearTimeout(timeoutId); 
}).mouseleave(function(){
    linc2.hide();
}); 

</script>