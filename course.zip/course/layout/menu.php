﻿<!DOCTYPE html>
<html>
<head>

  <meta http-equiv="content-type" content="text/html" charset="utf-8">
  <link href="./css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
 
</head>

<body>

<?php  
if(!isset($_SESSION['login']) and empty($_SESSION['login'])) {

echo "
<button class='knopka' >
      <a  href='index.php?action=login'><p>Вхід</p></a>
      </button>";
}
else{

echo "
<button class='knopka' >
      <a  href='index.php?action=logout'><p>Вихід</p></a>
      </button>";
}
?>

     </ul>
   </div>
      </nav>